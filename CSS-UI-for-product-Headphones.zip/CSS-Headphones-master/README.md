
# To-Do-List

This Project consists of a UI-UX design for a Card Holder for an E-commerce store containing the product details and even beutification element for the placard. 


## The Demo of working

This is how the programme looks like when done in function

![Headphones](https://user-images.githubusercontent.com/71783722/128621278-05f31555-c244-49a6-ac77-7e22a69c4950.gif)

## Features

- Hover Techniques 
- Use of Key Frames and Animation
- Could be used in E-Commerce sites for display of products




  
## FAQ

#### Languages Used

Html, CSS 

## Authors

- [@Shivam Jha](https://github.com/shivam-jha2712)

  